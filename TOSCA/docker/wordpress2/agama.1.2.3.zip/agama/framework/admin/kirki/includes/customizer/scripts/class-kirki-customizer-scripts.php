<?php

if ( ! class_exists( 'Kirki_Customizer_Scripts' ) ) {
	class Kirki_Customizer_Scripts extends Kirki_Customizer {

	}
}
